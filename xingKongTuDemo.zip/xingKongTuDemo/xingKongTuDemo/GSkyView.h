//
//  GSkyView.h
//  xingKongTuDemo
//
//  Created by  北斗国科 on 16/12/5.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GSkyView : UIView

@property (nonatomic, assign) CGFloat redio; // 最小空心圆半径
@property (nonatomic, strong) NSMutableArray *dataArr; // 存放Model

@end

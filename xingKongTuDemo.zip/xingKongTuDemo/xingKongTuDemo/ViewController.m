//
//  ViewController.m
//  xingKongTuDemo
//
//  Created by  北斗国科 on 16/12/5.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#import "ViewController.h"
#import "GSkyView.h" // 星空图View

#import "GSatelliteModel.h" // 卫星medol

@interface ViewController ()

@property (nonatomic, strong) GSkyView *gSkyView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    卫星编号PRN 方位角AZ 高度角
//    G01   51.7   12.0_  G02  250.5   13.3_  G03   56.2   38.9_  G06  268.1   48.4_  G10  190.0   28.2_ G17  354.2   58.8_ G23  103.7    7.0_ G28  171.0   62.8_ C06  164.1   42.2_ C09  184.4   21.2_ C14  180.8   27.8
    
    self.view.backgroundColor = RGBCOLOR(238, 238, 238);
    CGFloat width = (SWidth-40)/8.0;
    _gSkyView = [[GSkyView alloc]initWithFrame:CGRectMake(0, 40, SWidth, SWidth-2*width)];
    
    [self.view addSubview:_gSkyView];
    
    GSatelliteModel *model = [GSatelliteModel new];
    model.name = @"G01";
    model.azimuth = [@"51.7" floatValue];
    model.height = [@"12.0" floatValue];
    
    GSatelliteModel *model1 = [GSatelliteModel new];
    model1.name = @"G02";
    model1.azimuth = [@"250.5" floatValue];
    model1.height = [@"13.3" floatValue];

    GSatelliteModel *model2 = [GSatelliteModel new];
    model2.name = @"R12";
    model2.azimuth = [@"56.2" floatValue];
    model2.height = [@"38.9" floatValue];

    GSatelliteModel *model3 = [GSatelliteModel new];
    model3.name = @"G06";
    model3.azimuth = [@"268.1" floatValue];
    model3.height = [@"48.4" floatValue];

    GSatelliteModel *model4 = [GSatelliteModel new];
    model4.name = @"C14";
    model4.azimuth = [@"182.0" floatValue];
    model4.height = [@"27.8" floatValue];
    
    GSatelliteModel *model5 = [GSatelliteModel new];
    model5.name = @"R05";
    model5.azimuth = [@"290.8" floatValue];
    model5.height = [@"27.8" floatValue];
    
    NSMutableArray *mArr = [NSMutableArray array];
    [mArr addObject:model];
    [mArr addObject:model1];
    [mArr addObject:model2];
    [mArr addObject:model3];
    [mArr addObject:model4];
    [mArr addObject:model5];
    _gSkyView.dataArr = mArr;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

//
//  GSatelliteModel.h
//  xingKongTuDemo
//
//  Created by  北斗国科 on 16/12/5.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface GSatelliteModel : NSObject

@property (nonatomic, copy) NSString *name; // 卫星名称
@property (nonatomic, assign) CGFloat azimuth; // 方位角
@property (nonatomic, assign) CGFloat height; // 高度角

@end

//
//  GSkyView.m
//  xingKongTuDemo
//
//  Created by  北斗国科 on 16/12/5.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#import "GSkyView.h"
#import "GSatelliteModel.h" // 卫星medol

@implementation GSkyView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        self.backgroundColor = [UIColor whiteColor];
        _dataArr = [NSMutableArray array];
        [self configView];
    }
    return self;
}

- (void)configView {
    _redio = (SWidth-40)/8.0;
    
    CGFloat width = _redio;
    
    CGRect xRect = CGRectMake(20+width, 20+width*3, SWidth-(20+width)*2, 2);
    
    //写字 NEWS
    [self writeStringMethod];
    
    // 画标注实心圆
    [self drawCircle];
    
    // 划线
    for (int i = 0; i < 6; i++) {
        CALayer *line30 = [self xyLayerRect:xRect];
        line30 = [self lineLayerPath:line30 num:i];
        [self.layer addSublayer:line30];
    }
    
    // 画空心圆
    for (int i = 1; i<4; i++) {
        CAShapeLayer *circle = [self circleRiduo:i wieth:width];
        [self.layer addSublayer:circle];
    }
}

//写字，NEWS
- (void)writeStringMethod {
    CGFloat width = _redio;
    
    CGRect titleRect = CGRectMake(0, 0, 60, 20);
    CATextLayer *titleLayer = [self layerStringRect:titleRect num:14];
    titleLayer.alignmentMode = kCAAlignmentLeft;
    titleLayer.string = @"星空图";
    [self.layer addSublayer:titleLayer];
    
    CGRect NRect = CGRectMake(SWidth/2-10, 0, 20, 20);
    CATextLayer *NLayer = [self layerStringRect:NRect num:12];
    NLayer.string = @"N";
    [self.layer addSublayer:NLayer];
    
    CGRect SRect = CGRectMake(SWidth/2-10, CGRectGetHeight(self.frame)-20, 20, 20);
    CATextLayer *SLayer = [self layerStringRect:SRect num:12];
    SLayer.string = @"S";
    [self.layer addSublayer:SLayer];
    
    CGRect ERect = CGRectMake(SWidth-width-20, CGRectGetHeight(self.frame)/2-10, 20, 20);
    CATextLayer *ELayer = [self layerStringRect:ERect num:12];
    ELayer.string = @"E";
    [self.layer addSublayer:ELayer];
    
    CGRect WRect = CGRectMake(width, CGRectGetHeight(self.frame)/2-10, 20, 20);
    CATextLayer *WLayer = [self layerStringRect:WRect num:12];
    WLayer.string = @"W";
    [self.layer addSublayer:WLayer];
}

- (void)drawCircle {
    CGFloat redio = _redio/4;
    CGFloat width = redio*2;
//    CGFloat height = _redio-20;
    
    CGRect GRect = CGRectMake(5, width, width, width);
    CAShapeLayer *GLayer = [self colorCircleRext:GRect color:[UIColor greenColor]];
    [self.layer addSublayer:GLayer];
    
    CGRect GStrRect = CGRectMake(5+width, width*2+3, width, width);
    CATextLayer *GStrLayer = [self layerStringRect:GStrRect num:12];
    GStrLayer.string = @"G";
    [self.layer addSublayer:GStrLayer];
    
    
    CGRect RRect = CGRectMake(5, width*2+5, width, width);
    CAShapeLayer *RLayer = [self colorCircleRext:RRect color:[UIColor redColor]];
    [self.layer addSublayer:RLayer];
    
    CGRect RStrRect = CGRectMake(5+width, (width*2+5)*2+3, width, width);
    CATextLayer *RStrLayer = [self layerStringRect:RStrRect num:12];
    RStrLayer.string = @"R";
    [self.layer addSublayer:RStrLayer];
    
    
    CGRect CRect = CGRectMake(5, width+(width+5)*2, width, width);
    CAShapeLayer *CLayer = [self colorCircleRext:CRect color:[UIColor blueColor]];
    [self.layer addSublayer:CLayer];
    
    CGRect CStrRect = CGRectMake(5+width, (width+(width+5)*2)*2+3, width, width);
    CATextLayer *CStrLayer = [self layerStringRect:CStrRect num:12];
    CStrLayer.string = @"C";
    [self.layer addSublayer:CStrLayer];
    
}

// 获取CATextLayer
- (CATextLayer *)layerStringRect:(CGRect)rect num:(CGFloat)num {
    CATextLayer *titleLayer = [CATextLayer layer];
    titleLayer.frame = rect;
    UIFont *font = [UIFont systemFontOfSize:num];
    CFStringRef fontnName = (__bridge CFStringRef)font.fontName;
    CGFontRef fontRef = CGFontCreateWithFontName(fontnName);
    titleLayer.font = fontRef;
    titleLayer.fontSize = font.pointSize;
    titleLayer.contentsScale = [UIScreen mainScreen].scale;
    CGFontRelease(fontRef);
    titleLayer.alignmentMode = kCAAlignmentCenter;
    titleLayer.foregroundColor = [UIColor blackColor].CGColor;
    
    return titleLayer;
}

// 画标注圆
- (CAShapeLayer *)colorCircleRext:(CGRect)rect color:(UIColor *)color{
    CAShapeLayer *circle = [CAShapeLayer layer];
    circle.frame = rect;
    circle.fillColor = color.CGColor;
    circle.lineWidth = 2;
    circle.strokeColor = color.CGColor;
    
    UIBezierPath *circlePath = [UIBezierPath bezierPathWithOvalInRect:rect];
    circle.path = circlePath.CGPath;
    
//    circle.path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(rect.origin.x, rect.origin.y) radius:rect.size.width startAngle:0 endAngle:2*M_PI clockwise:YES];
    
    return circle;
}

// 画空心圆
- (CAShapeLayer *)circleRiduo:(int)num  wieth:(CGFloat)width{

    CAShapeLayer *circleLayer = [CAShapeLayer layer];
    // 指定frame，只是为了设置宽度和高度
    CGRect frame = CGRectMake(20+4*width, 20+3*width, width*num*2, width*num*2);
    
    circleLayer.frame = frame;
    // 设置居中显示
    circleLayer.position = CGPointMake(0 , 0);
    // 设置填充颜色
    circleLayer.fillColor = [UIColor clearColor].CGColor;
    // 设置线宽
    circleLayer.lineWidth = 2.0;
    // 设置线的颜色
    circleLayer.strokeColor = [UIColor blackColor].CGColor;
    // 使用UIBezierPath创建路径
    UIBezierPath *circlePath = [UIBezierPath bezierPathWithOvalInRect:frame];
    // 设置CAShapeLayer与UIBezierPath关联
    circleLayer.path = circlePath.CGPath;
    
    return circleLayer;
}

// 创建CALayer
- (CALayer *)xyLayerRect:(CGRect)rect {
    CALayer *layer = [CALayer layer];
    layer.frame = rect;
    layer.backgroundColor = [UIColor blackColor].CGColor;
    
    return layer;
}

// 划线
- (CALayer *)lineLayerPath:(CALayer *)layer num:(int)num{
     CATransform3D transform = CATransform3DIdentity;
    //在X轴上做一个30度的小旋转 在那个轴上面旋转就是对应的坐标值为1，当前为X轴旋转
    transform = CATransform3DRotate(transform, M_PI/6*num, 0, 0, 1);
    //设置CALayer的sublayerTransform
    layer.transform = transform;
    
    return layer;
}

// 数据源数组的set方法
- (void)setDataArr:(NSMutableArray *)dataArr {
    _dataArr = dataArr;
    [self drawSpot];
}

// 描点
- (void)drawSpot {
    if (_dataArr.count == 0) return;
    
    CGFloat redio = _redio/4;
    CGFloat width = redio*2; // 卫星点width
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        // 耗时操作，需放在分线程中；
        for (GSatelliteModel *model in _dataArr) {
            
            CGFloat AZ = model.azimuth;
            CGFloat coorY = 3*_redio - (_redio/30)*model.height;
            CGFloat yuanX = 20+4*_redio;
            CGFloat yuanY = 20+3*_redio;
            
            // 根据卫星方位角和高度角，转换为坐标
            if (AZ > 270) {
                CGPoint point;
                point.x = cos((AZ-270)*M_PI/180)*coorY;
                point.y = sin((AZ-270)*M_PI/180)*coorY;
                
                CGPoint coorPoint;
                coorPoint.x = yuanX - point.x-width/2;
                coorPoint.y = yuanY - point.y-width/2;
                
                [self drawSpotAndWrite:coorPoint width:width string:model.name];
                
            }
            else if (AZ > 180) {
                CGPoint point;
                point.x = sin((AZ-180)*M_PI/180)*coorY;
                point.y = cos((AZ-180)*M_PI/180)*coorY;
                
                CGPoint coorPoint;
                coorPoint.x = yuanX - point.x-width/2;
                coorPoint.y = yuanY + point.y-width/2;
                
                [self drawSpotAndWrite:coorPoint width:width string:model.name];
              
            }
            else if (AZ > 90) {
                CGPoint point;
                point.x = cos((AZ-90)*M_PI/180)*coorY;
                point.y = sin((AZ-90)*M_PI/180)*coorY;
                
                CGPoint coorPoint;
                coorPoint.x = yuanX + point.x-width/2;
                coorPoint.y = yuanY + point.y-width/2;
                
                [self drawSpotAndWrite:coorPoint width:width string:model.name];
               
            }
            else {
                
                CGPoint point;
                point.x = sin((AZ)*M_PI/180)*coorY;
                point.y = cos((AZ)*M_PI/180)*coorY;
                
                CGPoint coorPoint;
                coorPoint.x = yuanX + point.y-width/2;
                coorPoint.y = yuanY - point.x-width/2;
                
                [self drawSpotAndWrite:coorPoint width:width string:model.name];
               
            }
        }
//        dispatch_async(dispatch_get_main_queue(), ^{
//            // 更新界面
//        });
    });
}

// 根据卫星CGPoint 绘制卫星
- (void)drawSpotAndWrite:(CGPoint)point width:(CGFloat)width string:(NSString *)name{
    NSString *str = [name substringToIndex:1]; // 取第一个字母，判断卫星类型
    
    UIColor *color; // 根据不同类型名称，绘制不同颜色
    if ([str isEqualToString:@"G"]) {
        color = [UIColor greenColor];
    }
    else if ([str isEqualToString:@"R"]) {
        color = [UIColor redColor];
    }
    else {
        color = [UIColor blueColor];
    }
    
    // 绘制卫星
    CGRect rect = CGRectMake(point.x/2, point.y/2, width, width);
    CAShapeLayer *GLayer = [self colorCircleRext:rect color:color];
    [self.layer addSublayer:GLayer];
    
    // 写卫星名称
    CGRect rect1 = CGRectMake(point.x, point.y+5, width, width);
    CATextLayer *CStrLayer = [self layerStringRect:rect1 num:8];
    CStrLayer.string = name;
    CStrLayer.foregroundColor = [UIColor whiteColor].CGColor;
    [self.layer addSublayer:CStrLayer];
}


@end

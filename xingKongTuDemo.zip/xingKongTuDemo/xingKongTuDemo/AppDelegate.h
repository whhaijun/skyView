//
//  AppDelegate.h
//  xingKongTuDemo
//
//  Created by  北斗国科 on 16/12/5.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

